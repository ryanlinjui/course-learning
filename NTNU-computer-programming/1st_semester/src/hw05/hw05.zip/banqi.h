#pragma once
#include <stdint.h>

void loop_game();
