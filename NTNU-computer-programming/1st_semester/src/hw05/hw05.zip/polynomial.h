#pragma once

#include <stdint.h>
#include <stddef.h>
void calculate_result(int64_t p1[],int8_t p1_size,int64_t p2[],int8_t p2_size);