#pragma once
#include <stdint.h>

int *available(uint32_t element[],int color);