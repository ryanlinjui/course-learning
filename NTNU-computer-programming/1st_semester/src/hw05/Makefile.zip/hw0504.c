#include <stdio.h>
#include "banqi.h"

int main()
{
    printf("$ ./hw0504\n");
    loop_game();
    return 0;
}