Student ID:41047035S
Student Name:林昕鋭

Hw0501:Big Two

Hw0502:Statistics

Hw0503:Polynomial Calculator

Hw0504:Banqi

Bonus:An Interesting Code