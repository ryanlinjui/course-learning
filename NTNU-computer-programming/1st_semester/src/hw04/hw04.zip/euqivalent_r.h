#pragma once

#include <stdint.h>
double calculate(double r_value,int n_value);