// #ifndef K_FUNCTION_INCLUDED
// #define K_FUNCTION_INCLUDED

#pragma once

#include <stdint.h>
void k_print(int64_t n);

// #endif