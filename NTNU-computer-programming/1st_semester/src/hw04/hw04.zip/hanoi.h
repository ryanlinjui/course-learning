#pragma once

void hanoi_recursive(int n,int t1,int t2,int t3,int disk);

void hanoi_iterative(int n,int t1,int t2,int t3,int disk);