#pragma once

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include <stdbool.h>
#include <math.h> //add -lm in Makefile to link math.h
#include <ctype.h>
#include <inttypes.h>

#include <sys/mman.h> //mmap
#include <fcntl.h>  //mmap
#include <sys/stat.h>