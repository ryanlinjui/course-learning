> **Student ID: 41047035S**  
> **Student Name: 林昕鋭**  
> **Teacher Name: 紀博文**  
> **Finish Date: 2022/06/04**

## To build all code, please run:
```
make
```
---
## fin01 Color Gradient
### 
#### Imformation
```
./fin01 --help
```
#### Excute
```
./fin01
```

---
## fin02 COVID-19
###
#### Imformation
```
./fin02 --help
```
#### Excute
```
./fin02
```
---
## fin03 Maze 
### 
#### Imformation
```
./fin03 --help
```
#### Excute
```
./fin03
```